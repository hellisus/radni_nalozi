require('a');
require('b');
require('c' + x);
var moo = require('d' + y).moo;
