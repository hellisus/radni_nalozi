import { cloneDeep } from '../util/cloneDeep'
import defaultConfig from '../../stubs/defaultConfig.stub'

export default cloneDeep(defaultConfig)
