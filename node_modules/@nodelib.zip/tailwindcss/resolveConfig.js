let resolveConfig = require('./lib/public/resolve-config')
module.exports = (resolveConfig.__esModule ? resolveConfig : { default: resolveConfig }).default
